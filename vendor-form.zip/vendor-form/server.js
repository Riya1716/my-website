const express = require('express');
const fs = require('fs');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(bodyParser.json());

app.post('/register', (req, res) => {
  const newEntry = req.body;

  fs.readFile('data.json', 'utf8', (err, data) => {
    let json = [];
    if (!err && data) {
      json = JSON.parse(data);
    }

    json.push(newEntry);

    fs.writeFile('data.json', JSON.stringify(json, null, 2), (err) => {
      if (err) {
        return res.status(500).json({ message: 'Failed to save data' });
      }
      res.json({ message: 'Data saved successfully!' });
    });
  });
});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
